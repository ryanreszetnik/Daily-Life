const Responses = {
  USERS: "task-org-users",
  EVENTS: "task-org-events",
  TASKS: "task-org-tasks",
};

module.exports = Responses;
